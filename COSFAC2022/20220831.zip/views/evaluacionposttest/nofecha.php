
<?php 
$this->title = 'Está fuera de la fecha programada para éste test';
?>

<h2>
    <?= $this->title?>
</h2>
La fecha programada para  su evaluación  es : 

<table  style="width: 100%">
    <thead>
        <tr>
            <th>Fecha de Inicio</th>
            <th>Fecha de Fin</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><?= $inicio?></td>
            <td><?= $fin?></td>
        </tr>
        <tr>
            <td colspan="2">
                <div class="alert alert-warning" role="alert"><?php echo htmlentities($descripcion); ?></div>
            </td>
        </tr>
    </tbody>
</table>


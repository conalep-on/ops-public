<?php
/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
//use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\bootstrap4\NavBar;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">


    <head>
        <script type="text/javascript">

            function stopRKey(evt) {
                var evt = (evt) ? evt : ((event) ? event : null);
                var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
                if ((evt.keyCode === 13) && (node.type === "text")) {
                    return false;
                }
            }

            document.onkeypress = stopRKey;

        </script>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSS -->
        <link href="<?= yii\helpers\Url::home(true) ?>/favicon.ico" rel="shortcut icon">
        <link href="https://framework-gb.cdn.gob.mx/assets/styles/main.css" rel="stylesheet">

        <!-- Respond.js soporte de media queries para Internet Explorer 8 -->
        <!-- ie8.js EventTarget para cada nodo en Internet Explorer 8 -->
        <!--[if lt IE 9]>
          <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/ie8/0.2.2/ie8.js"></script>
        <![endif]-->

        <?php $this->registerCsrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <?php //$this->head()   ?>


        
    </head>


    <body >
        <?php $this->beginBody() ?>

        <main class="page">

            <nav class="navbar navbar-inverse sub-navbar navbar-fixed-top">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#subenlaces">
                            <span class="sr-only">Interruptor de Navegación</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>

                    </div>
                    <div class="collapse navbar-collapse" id="subenlaces">
                        <ul class="nav navbar-nav navbar-right">

                            <li><?= Html::a('Inicio', ['/site/index']) ?></li>

                            <!--<li><?= Html::a('Manual del usuario', yii\helpers\Url::home() . 'ManualUsuaruio_EDIEMS2019.pdf', ['target' => '_blank']) ?></li> -->
                          <!--    <li><?= Html::a('Manual captura de resultados', yii\helpers\Url::home() . 'Manual_del_sistema_de_captura_de_los_resultados.pdf', ['target' => '_blank']) ?></li> -->
                      
                            <li><?= Html::a('Preguntas frecuentes', yii\helpers\Url::home() . 'faq.pdf', ['target' => '_blank']) ?></li>

                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Carga de archivo txt <span class="caret"></span></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><?= Html::a('Manual de carga', yii\helpers\Url::home(true) . 'Manualtxt2022_2023.pdf', ['target' => '_blank']) ?></li>
                                    <li><?= Html::a('Ejemplo archivo txt', yii\helpers\Url::home(true) . 'ejemplodecargatxt_2022_2023.txt?dl=1', ['target' => '_blank', 'download' => 'ejemplo.txt']) ?></li>
                                    <li><?= Html::a('Ejemplo archivo xlsx', yii\helpers\Url::home(true) . 'ejemplode carga2022_2023.xlsx?dl=1', ['target' => '_blank', 'download' => 'ejemplo.xlsx']) ?></li>

                                </ul>
                            </li>


                            <?php if (!Yii::$app->user->isGuest): ?><li> <?=
                                    Html::beginForm(['/site/logout'], 'post')
                                    . Html::submitButton(
                                            'Salir (' . \Yii::$app->session->get('Cct') . ')' . \Yii::$app->session->get('Turno'),
                                            ['class' => 'btn btn-link', 'style' => 'padding-top: 20px;']
                                    )
                                    . Html::endForm()
                                    ?>    </li> <?php endif; ?>

                        </ul>
                    </div>
                </div>
            </nav>     







            <div class="container">
                <?=
                Breadcrumbs::widget([
                    'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
                ])
                ?>
                <?= Alert::widget() ?>
                <p>&nbsp</p>
                <p>&nbsp</p>
                <?= $content ?>

                <p>&nbsp</p>
                <p>&nbsp</p>
            </div>




            <?php $this->endBody() ?>

        </main>    
        <!-- JS -->
        <script src="https://framework-gb.cdn.gob.mx/gobmx.js"></script>

    </body>
</html>
<?php $this->endPage() ?>

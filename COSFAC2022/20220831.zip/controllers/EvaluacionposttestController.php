<?php

namespace app\controllers;

class EvaluacionposttestController extends \yii\web\Controller
{
    public function actionIndex()
    {
        $model = New \app\models\TestForm();
        
     if ($model->load(\Yii::$app->request->post())&& $model->validate() ) {
        // $aplicadores = \app\models\Aplicadores::findOne(['password'=>$model->aplicador]) ;
         $alumno = \app\models\RegistroAlumnos::findOne(['password'=>$model->alumno]);
     
         if( $alumno <>null){
               $usuario = \app\models\Usuarios::findOne(['turno' => $alumno->turno, 'cct'=>$alumno->cct]);
            
            $this->validafecha($alumno->cct);
            
             $examen = \app\models\ExamenesP::findOne(['capturo'=> $alumno->capturo,'cct'=>$alumno->cct, 'folio'=>$alumno->folio ]);
                     
             if( $examen == null){
               $examen = new \app\models\ExamenesP();
               $examen->cct=  $alumno->cct;
               $examen->turno = $alumno->turno;
               $examen->genero= $alumno->genero;
               $examen->edad= $alumno->edad;
               $examen->promedio= $alumno->promedio;
               $examen->tipo = $alumno->tipo_secundaria;
               $examen->sostenimiento= $alumno->sostenimiento;
               $examen->capturo= $alumno->capturo;
               $examen ->folio= $alumno->folio;
                 $examen->curp=$alumno->curp;
                    $examen->tipo_evaluacion= 2;//
               $examen->save(false);
               $examen = \app\models\ExamenesP::findOne(['capturo'=> $alumno->capturo,'cct'=>$alumno->cct, 'folio'=>$alumno->folio ]);
             }
            
             
                     
           return $this->redirect(['test', 'id' => base64_encode($examen->id)  ]);
         } else {
            \Yii::$app->session->setFlash('error', 'No se encontró alumno con la contraseña proporcionada.');
         } 
        } elseif (\Yii::$app->request->isPost) {    
            \Yii::$app->session->setFlash('error', 'Debes proporcionar una contraseña.');
        }

        return $this->render('index' ,['model'=>$model]);
    }
    
    public function actionTest($id){
        $this->layout='examen';
        $idr= base64_decode($id);
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
        $alumno= \app\models\RegistroAlumnos::findOne(['cct'=>$examen->cct, 'folio'=>$examen->folio]);
          $this->validafecha($alumno->cct);
//         if ($examen->rcm > 80) {
//             $examen->rcm = 80;
//         }
        if ($examen->estatus == 1) {
            return $this->redirect(['enviado', 'id' => $id]);
        }
     
        
        if ($examen->load(\Yii::$app->request->post())&& $examen->save()){
        return  $this->redirect(['testcm','id'=>$id ]);
        }
               
         return $this->render('testcl' ,['examen'=>$examen,'alumno'=>$alumno]);
        
    }

    public function actionTestcm($id){
         $this->layout='examen';
        $idr= base64_decode($id);
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
        $alumno= \app\models\RegistroAlumnos::findOne(['cct'=>$examen->cct, 'folio'=>$examen->folio]);
          $this->validafecha($alumno->cct);
        if($examen->estatus ==1){
             return  $this->redirect(['enviado','id'=>$id ]);
        }
        
         if ($examen->load(\Yii::$app->request->post())&& $examen->save()){
         return   $this->redirect(['testcs','id'=>$id ]);
        }
         return $this->render('testcm' ,['examen'=>$examen,'alumno'=>$alumno]);
        
    }
     public function actionTestcetn($id){
         $this->layout='examen';
        $idr= base64_decode($id);
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
        $alumno= \app\models\RegistroAlumnos::findOne(['cct'=>$examen->cct, 'folio'=>$examen->folio]);
          $this->validafecha($alumno->cct);
        if($examen->estatus ==1){
             return  $this->redirect(['enviado','id'=>$id ]);
        }
        
         if ($examen->load(\Yii::$app->request->post())&& $examen->save()){
         return   $this->redirect(['preenvio','id'=>$id ]);
        }
         return $this->render('testcetn' ,['examen'=>$examen,'alumno'=>$alumno]);
        
    }

   
     public function actionTestce($id){
         $this->layout='examen';
        $idr= base64_decode($id);
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
        $alumno= \app\models\RegistroAlumnos::findOne(['cct'=>$examen->cct, 'folio'=>$examen->folio]);
          $this->validafecha($alumno->cct);
        if($examen->estatus ==1){
             return  $this->redirect(['enviado','id'=>$id ]);
        }
        
         if ($examen->load(\Yii::$app->request->post())&& $examen->save()){
         return   $this->redirect(['testcetn','id'=>$id ]);
        }
         return $this->render('testce' ,['examen'=>$examen,'alumno'=>$alumno]);
        
    }
    
    public function actionTestcs($id){
         $this->layout='examen';
        $idr= base64_decode($id);
//       $dgb=['09DCB0001I','09DCB0003G','09DCB0005E','09DCB0007C','15DCB0001T',
//           '09DCB0009A','09DCB0011P','09DCB0013N','09DCB0015L','09DCB0017J',
//'09DCB0019H','15DCB0002S','09DCB0021W','09DCB0023U','09DCB0025S','09DCB0027Q',
//'09DCB0029O','09DCB0031C', '15DCB0003R', '09DCB0033A'
//];
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
        $alumno= \app\models\RegistroAlumnos::findOne(['cct'=>$examen->cct, 'folio'=>$examen->folio]);
//        if( in_array($examen->cct,$dgb) ){
//            $examen->rce= 10;
//            $examen->save();
//             return   $this->redirect(['preenvio','id'=>$id ]);
//        }
        
        
          $this->validafecha($alumno->cct);
         if($examen->estatus ==1){
             return  $this->redirect(['enviado','id'=>$id ]);
        }
       if ($examen->load(\Yii::$app->request->post())&& $examen->save()){
         return   $this->redirect(['testce','id'=>$id ]);
        }
        
         return $this->render('testcs' ,['examen'=>$examen,'alumno'=>$alumno]);
        
    }
    
    public function actionPreenvio($id){
         $this->layout='examen';
        $idr= base64_decode($id);
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
        $alumno= \app\models\RegistroAlumnos::findOne(['cct'=>$examen->cct, 'folio'=>$examen->folio]);
          $this->validafecha($alumno->cct);
        
        
        if ($examen->load(\Yii::$app->request->post())&& $examen->save()){
         return   $this->redirect(['envio','id'=>$id ]);
        }
        
         return $this->render('preenvio' ,['examen'=>$examen,'alumno'=>$alumno]);
        
    }
    
    
     public function actionEnviar($id){
        $idr= base64_decode($id);
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
        $examen->estatus =1;
        $examen->save(false);
         return   $this->redirect(['enviado','id'=>$id ]);
        // return $this->render('preenvio' ,['examen'=>$examen]);
        
    }
    
      public function actionEnviado($id){
        $idr= base64_decode($id);
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
       $alumno= \app\models\RegistroAlumnos::findOne(['cct'=>$examen->cct, 'folio'=>$examen->folio]);
         return $this->render('enviado' ,['examen'=>$examen,'alumno'=>$alumno]);
        
    }
    
    public function actionEnviadopdf($id) {
         $idr= base64_decode($id);
        $examen = \app\models\ExamenesPTest::findOne(['id'=>$idr]);
       $alumno= \app\models\RegistroAlumnos::findOne(['cct'=>$examen->cct, 'folio'=>$examen->folio]);
         $documento = new \Mpdf\Mpdf(['mode' => 'utf-8', // mode - default ''
            'format' => 'LETTER', // format - A4, for example, default ''
            '', // font size - default 0
            '', // default font family
            'margin_left' => 15, // margin_left
            'margin_right' => 15, // margin right
            'margin_top' => 35, // margin top
            'margin_bottom' => 20, // margin bottom
            'margin_header' => 7, // margin header
            'margin_footer' => 12, // margin footer
            'orientation' => 'P']);
         
          $documento->WriteHTML($this->renderPartial('enviadopdf', ['examen'=>$examen,'alumno'=>$alumno]));

        $documento->Output('evaluacion' . $id . '.pdf', 'I');
         
          exit;
    }
    
      public function actionNolinea($id) {
        return $this->render('nolinea');
    }

       public function actionNofecha($inicio,$fin, $descripcion = '') {
        return $this->render('nofecha',[ 'inicio'=>$inicio, 'fin'=>$fin, 'descripcion' => $descripcion]);
    }

    public function validafecha($cct){
         $examen_linea = \app\models\ExamenOnline::findOne(['cct' => $cct]);
                if ($examen_linea == null) {
                    return $this->redirect(['nolinea', 'id' => $cct]);
                } else {
                  if (empty($examen_linea->postest_inicio) || empty($examen_linea->postest_inicio)) {
                    return $this->redirect(['nofecha', 'inicio' => 'No asignado', 'fin' => 'No asignado', 'descripcion' => 'El plantel con CCT: ' . $cct . ' no tiene agendado un periodo de post-test. Comunícate con tu plantel para que solicite sea agendada.']);
                  }

                    $fecha_inicio = new \DateTime($examen_linea->postest_inicio, new \DateTimeZone('America/Mexico_City'));
                    $fecha_final = new \DateTime($examen_linea->postest_fin, new \DateTimeZone('America/Mexico_City'));
                    $hoy = new \DateTime("now", new \DateTimeZone('America/Mexico_City'));

                    if (
                      !($fecha_inicio->getTimestamp() <= $hoy->getTimestamp() && $hoy->getTimestamp() <= $fecha_final->getTimestamp())
                    ) {

                        return $this->redirect(['nofecha', 'inicio' => $examen_linea->postest_inicio, 'fin' => $examen_linea->postest_fin, 'descripcion' => 'El periodo para contestar el post-test no está vigente.']);
                    }
                }
        return true;
    }
    
}

<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;

class PosttestController extends \yii\web\Controller {

    public function behaviors() {
        return [
            'access' => [
                'class' => AccessControl::className(),
                //   'only' => ['logout','plantel'],
                'rules' => [
                    [
                        'actions' => ['index', 'reportexestudiante', 'reportepna', 'reportemdh', 'reportes', 'reportele'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
        ];
    }

    public function actionIndex($usuario = null) {
        If ($usuario == null) {
            $usuario = \Yii::$app->session->get('Usuario');
        }
        $usuarios = \app\models\Usuarios::findOne(['id'=>$usuario]);
        $searchModel = new \app\models\VistaAciertosPSearch(['cct' => $usuarios->cct, 'turno'=>$usuarios->turno]);
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        $searchModela = new \app\models\RegistroAlumnosSearch(['cct' => $usuarios->cct, 'turno'=>$usuarios->turno]);
        $dataProvidera = $searchModela->search(Yii::$app->request->queryParams);

        return $this->render('index', [
                    'usuario' => $usuario,
                    'searchModel' => $searchModel,
                    'dataProvider' => $dataProvider,
                    'searchModela' => $searchModela,
                    'dataProvidera' => $dataProvidera,
        ]);
    }

    public function actionReportexestudiante($capturo) {
        $usuario = \app\models\Usuarios::findOne(['id' => $capturo]);
        $examenes = \app\models\EvaluacionPonderadaAlumnosP::findAll(['cct' => $usuario->cct,'turno'=>$usuario->turno]);
        ini_set("pcre.backtrack_limit", "10000000");
        ini_set('max_execution_time', 0);
        $documento = new \Mpdf\Mpdf(['mode' => 'utf-8', // mode - default ''
            'format' => 'LETTER', // format - A4, for example, default ''
            '', // font size - default 0
            '', // default font family
            'margin_left' => 15, // margin_left
            'margin_right' => 15, // margin right
            'margin_top' => 35, // margin top
            'margin_bottom' => 20, // margin bottom
            'margin_header' => 7, // margin header
            'margin_footer' => 12, // margin footer
            'orientation' => 'P']);
        $documento->WriteHTML($this->renderPartial('reportexestuduante', ['usuario' => $usuario, 'examenes' => $examenes]));

        $documento->Output('Reporte por estudiante' . $capturo . '.pdf', 'I');
        exit;
    }

    public function actionReportepna($capturo) {
         //$usuario = \app\models\Usuarios::findOne(['id' => $capturo]);
        //$datos = \app\models\ReportePnaPlantelesP::findOne(['cct' => $usuario->cct,'turno'=>$usuario->turno]);
        $datos = \app\models\ReportePnaP::findOne($capturo);
        return $this->render('reportepna', ['datos' => $datos]);
    }

    public function actionReportemdh($capturo) {
         $usuario = \app\models\Usuarios::findOne(['id' => $capturo]);
        $datos = \app\models\ReporteMdhP::findOne(['cct' => $usuario->cct,'turno'=>$usuario->turno]);
        return $this->render('reportemdh', ['datos' => $datos]);
    }

    public function actionReportes() {
        $usuario = \Yii::$app->session->get('Usuario');
        return $this->render('reportes', ['usuario' => $usuario]);
    }

    public function actionReportele() {
         ini_set('max_execution_time', 300);
        $usuario = \Yii::$app->session->get('Usuario');
                 
       $exporter = new \yii2tech\spreadsheet\Spreadsheet([
           'title' => 'Lista de estudiantes Postest',
            'dataProvider' => new \yii\data\ActiveDataProvider([
                'query' => \app\models\EvaluacionPonderadaAlumnosP::find()->where(['cct' => \Yii::$app->session->get('Cct'),'turno'=>\Yii::$app->session->get('Turno')]),
                'pagination' => [
            'pageSize' => 100, // export batch size
        ],
               
                
                
            ]),
         'columns' => [
                'folio',
                'nombre',
                'aciertos_cl', // Related attribute
                'aciertos_cm',
                'aciertos_cs',
                'aciertos_ce',
                'aciertos_cet',
                'aciertos',
                'promediol',
                'cll',
                'cml',
                'csl',
                'cel',
                'cetl',
            ],
           
        ]);
        return $exporter->send('Listaestudiantespostes' . date("Y-m-d H:i:s") . '.xls');
        
//        $file = \Yii::createObject([
//                    'class' => 'codemix\excelexport\ExcelFile',
//                    'sheets' => [
//                        'Users' => [
//                            'class' => 'codemix\excelexport\ActiveExcelSheet',
//                            'query' => \app\models\EvaluacionPonderadaAlumnos::find()->where(['capturo' => $usuario]),
//                            'attributes' => [
//                                'folio',
//                                'nombre',
//                                'aciertos_cm',
//                                'aciertos_cl', // Related attribute
//                                'aciertos_ce',
//                                'aciertos',
//                                'promediol',
//                                'nivel_dominio'
//                            ],
//                            'startRow' => 3,
//                            'on beforeRender' => function ($event) {
//                                $sheet = $event->sender->getSheet();
//                                $sheet->setCellValue('A1', 'Lista de Estudiantes');
//                            }
//                        ],
//                    ],
//        ]);
//        $file->send('Listaestudiantes.xlsx');

        exit();
    }

}

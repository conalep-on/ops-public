<?php

namespace app\models;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use Yii;
use kartik\password\StrengthValidator;

/**
 * This is the model class for table "usuarios".
 *
 * @property integer $id
 * @property string $CURP
 * @property string $cct
 * @property integer $tipo_usuario
 * @property integer $academia
 * @property string $nombre
 * @property string $apellido1
 * @property string $apellido2
 * @property string $correo
 * @property string $password
 * @property string $accessToken
 * @property integer $activate
 * @property string $creacion
 * @property string $modificacion
 */
class Usuarios extends \yii\db\ActiveRecord implements IdentityInterface
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'usuarios';
    }
    
//     public static function getDb()
//    {
//        return Yii::$app->get('dbusuarios');
//    }

    
    public $correo1;
    public $correo3;
    public $CURP1;
    public $estado;
    public $municipio;
    public $subsistema;
   
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [[ 'cct',  'correo','correo1','correo2','correo3','estado','subsistema','turno','password'], 'required'],
            [['tipo_usuario', 'academia', 'activate','turno'], 'integer'],
            [['correo','genero','subsistema','subsistemau','entidadu'], 'string'],
            [['creacion', 'modificacion'], 'safe'],
            [['CURP','CURP1'], 'string', 'max' => 18],
            [['cct'], 'string', 'max' => 10],
            [['correo','correo1','correo2','correo3'],'email'],
            [['nombre', 'apellido1', 'apellido2',  'accessToken'], 'string', 'max' => 50],
            [['cct', 'turno'], 'unique', 'targetAttribute' => ['cct', 'turno'], 'message' => 'La combinación CCT y turno ya está registrado, si desea conocer el correo registrado contactar a jczamora@conalep.edu.mx o al teléfono 7222710800 ext 2547'],
            [['CURP','CURP1'], 'match', 'pattern' =>'/^[a-zA-Z]{1}[aeiouxAEIOUX]{1}[a-zA-Z]{2}(\d{2})((01|03|05|07|08|10|12)(0[1-9]|[12]\d|3[01])|02(0[1-9]|[12]\d)|(04|06|09|11)(0[1-9]|[12]\d|30))[hmHM]{1}([aA][sS]|[bB][cC]|[bB][sS]|[cC][cC]|[cC][sS]|[cC][hH]|[cC][lL]|[cC][mM]|[dD][fF]|[dD][gG]|[gG][tT]|[gG][rR]|[hH][gG]|[jJ][cC]|[mM][cC]|[mM][nN]|[mM][sS]|[nN][tT]|[nN][lL]|[oO][cC]|[pP][lL]|[qQ][tT]|[qQ][rR]|[sS][pP]|[sS][lL]|[sS][rR]|[tT][cC]|[tT][sS]|[tT][lL]|[vV][zZ]|[yY][nN]|[zZ][sS]|[nN][eE])[B-DF-HJ-NP-TV-Z]{3}[0-9A-Z]{1}[0-9]{1}$/'],
            ['correo1','compare','compareAttribute'=>'correo','message'=>'El correo no es el mismo, reescriba nuevamente'],
            ['correo3','compare','compareAttribute'=>'correo2','message'=>'El correo alternativo no es el mismo, reescriba nuevamente'],
            ['CURP1','compare','compareAttribute'=>'CURP','message'=>'La CURP no es la misma, reescriba nuevamente'],
            [['subsistema','entidad'],'required', 'on'=>'academicos'],
            
              [['cct', 'turno'], 'unique', 'targetAttribute' => ['cct', 'turno']],
           [['cct'], 'exist', 'skipOnError' => true, 'targetClass' => Planteles2019::className(), 'targetAttribute' => ['cct' => 'cct']],
            	[['password'], StrengthValidator::className(), 'preset'=>'normal', 'userAttribute'=>'id']
     

        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'CURP' => 'CURP',
            'CURP1' => 'Reescribir CURP',
            'cct' => 'Clave de centro de trabajo',
            'tipo_usuario' => 'Tipo Usuario',
            'academia' => 'Academia',
            'nombre' => 'Nombre',
            'apellido1' => 'Primer apellido',
            'apellido2' => 'Segundo apellido',
            'correo' => 'Correo electrónico',
            'correo1' => 'Reescribir correo electrónico',
            'correo2'=>'Correo electrónico alternativo',
            'correo3'=>'Reescribir correo electrónico alternativo',
            'password' => 'Contraseña',
            'accessToken' => 'Access Token',
            'activate' => 'Activate',
            'creacion' => 'Creacion',
            'modificacion' => 'Modificacion',
            'genero'=>'Género',
            'turno'=>'Turno',
            'estado'=>'Entidad federativa',
            'subsistema'=> 'Subsistema',
            'subsistemau'=> 'Subsistema',
            'entidadu'=>'Entidad',
        ];
    }


      /**
     * Finds an identity by the given ID.
     *
     * @param string|integer $id the ID to be looked for
     * @return IdentityInterface|null the identity object that matches the given ID.
     */
    public static function findIdentity($id)
    {
            return Usuarios::findOne($id);
       
    }

      public static function findByUsername($username)
    {

       
        return $usuario = Usuarios::findOne(['id'=>$username]);
       
        
            
            


    }


    /**
     * Finds an identity by the given token.
     *
     * @param string $token the token to be looked for
     * @return IdentityInterface|null the identity object that matches the given token.
     */
    public static function findIdentityByAccessToken($token, $type = null)
    {
        return static::findOne(['accessToken' => $token]);
    }

    /**
     * @return int|string current user ID
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string current user auth key
     */
    public function getAuthKey()
    {
        return $this->accessToken;
    }

    /**
     * @param string $authKey
     * @return boolean if auth key is valid for current user
     */
    public function validateAuthKey($authKey)
    {
        return $this->getAuthKey() === $authKey;
    }



      public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if ($this->isNewRecord) {
                 $passwd= $this->password;
                $this->accessToken = $this->password;
                $this->password= Yii::$app->security->generatePasswordHash($passwd);
            }
            return true;
        }
        return false;
    }


    public function setPassword($password)
    {
        $this->password = Yii::$app->security->generatePasswordHash($password);
    }
    
    
     public function getCct0() 
   { 
       return $this->hasOne(Planteles2019::className(), ['cct' => 'cct']); 
   } 
    
    public function getTurno0() 
   { 
       return $this->hasOne(CatalogoTurno::className(), ['id' => 'turno']); 
   } 
    
       
     public function getEntidad()
    {
        return $this->cct0->entidad;
    }

    
     public function getSubsistema()
    {
        return $this->cct0->subsistema;
    }
    
    
     public function getEf()
    {
       $ef = CatalogoEntidadFederativa::findOne(['cve_oficial'=>$this->entidadu])  ;
         
        return $ef==null?'':$ef->nombre;
    }
    
    
    /**
    * @return \yii\db\ActiveQuery
    */
 


}

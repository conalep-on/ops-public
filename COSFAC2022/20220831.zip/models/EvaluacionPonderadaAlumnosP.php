<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "evaluacion_ponderada_alumnos_p".
 *
 * @property int $id
 * @property int $capturo
 * @property int $entidad
 * @property string $entidadn
 * @property string $subsistema
 * @property string $cct
 * @property int $turno
 * @property string $folio
 * @property int $tipo
 * @property int $promedio
 * @property string $genero
 * @property string $cm
 * @property string $cl
 * @property string $ce
* @property string $cet
 * @property string $cml
 * @property int $cmn
 * @property string $cll
 * @property int $cln
 * @property string $cel
  * @property string $cetl
 * @property int $cen
 * @property int $cetn
 * @property string $nombre
 * @property int $ida
 * @property string $aciertos_cm
 * @property string $aciertos_cl
 * @property string $aciertos_ce
 * @property string $aciertos_cet
 * @property string $aciertos
 * @property string $desc_cm
 * @property string $desc_cl
 * @property string $desc_ce
 * @property string $desc_cet
 * @property string $promediol
 */
class EvaluacionPonderadaAlumnosp extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'evaluacion_ponderada_alumnos_p';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'capturo', 'entidad', 'turno', 'folio', 'tipo', 'promedio', 'cm', 'cl', 'ce','cet', 'cmn', 'cln', 'cen', 'cetn','ida', 'aciertos_cm', 'aciertos_cl', 'aciertos_ce','aciertos_cet', 'aciertos'], 'integer'],
            [['capturo', 'cct', 'turno', 'folio'], 'required'],
            [['nombre', 'desc_cm', 'desc_cl', 'desc_ce','desc_cet'], 'string'],
            [['entidadn'], 'string', 'max' => 150],
            [['subsistema'], 'string', 'max' => 16],
            [['cct', 'promediol'], 'string', 'max' => 10],
            [['genero'], 'string', 'max' => 1],
            [['cml', 'cll', 'cel'], 'string', 'max' => 12],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
         return [
            'id' => 'ID',
            'capturo' => 'Capturo',
            'entidad' => 'Entidad',
            'entidadn' => 'Entidadn',
            'subsistema' => 'Subsistema',
            'cct' => 'Cct',
            'turno' => 'Turno',
            'folio' => 'Folio',
            'tipo' => 'Tipo',
            'promedio' => 'Promedio',
            'genero' => 'Genero',

            'cl' => 'Español',
            'cll' => 'Nivel de Español',
            'cln' => 'Español',
            'aciertos_cl' => 'Aciertos Español',

            'cm' => 'Matemáticas',
            'cml' => 'Nivel de Matemáticas',
            'cmn' => 'Cmn',
            'aciertos_cm' => 'Aciertos Matemáticas',

            'cs' => 'Nivel de Entorno Social',            
            'csl' => 'Nivel de Entorno Social',
            'csn' => 'Csn',
            'aciertos_cs' => 'Aciertos Entorno Social',

            'ce' => 'Ciencias Naturales',
            'cel' => 'Nivel de Ciencias Naturales',
            'cen' => 'Cen',
            'aciertos_ce' => 'Aciertos Ciencias Naturales',

            'cet' => 'Ética',
            'cetl' => 'Nivel de Ética',
            'cetn' => 'Cen',
            'aciertos_cet' => 'Aciertos Ética',
            
            'nombre' => 'Nombre',
            'ida' => 'Ida',
            'aciertos' => 'Total',
            'desc_cl' => 'Desc Español',
            'desc_cm' => 'Desc Matemáticas',
            'desc_cs' => 'Desc Entorno Social',
            'desc_ce' => 'Desc Ciencias Naturales',
            

            'promediol' => 'Promedio de secundaria',
        ];
    }
    
      public function getNivel_dominio()
    {
          $nd=$this->cm + $this->cl+ $this->ce;
                      return $nd<17?'Insuficiente':( $nd<83?'Elemental':( $nd<200?'Intermedio':'Avanzado'    )      );
    }
    
  
    
}

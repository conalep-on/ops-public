<?php

use yii\helpers\Html;
use kartik\form\ActiveForm;
use kartik\password\PasswordInput;
use yii\helpers\ArrayHelper;
use kartik\depdrop\DepDrop;
use yii\helpers\Url;
$lentidad= ArrayHelper::map(\app\models\CatalogoEntidadFederativa::find()->all(),'cve_entidad_federativa','nombre');
$lturno= ArrayHelper::map(app\models\CatalogoTurno::find()->all(), 'id', 'turno');

/* @var $this yii\web\View */
/* @var $model app\models\Usuarios */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="usuarios-form">
<HR class="red">
<div class="alert alert-info" role="alert" style="text-align:justify;">
    <strong>ATENCIÓN:</strong> Si al completar el llenado del formulario y enviarlo aparece el mensaje que el plantel ya existe, significa que la combinación CCT y turno ya existe. Si usted tiene dudas de qué correos están registrado, envíe un correo a <a class="btn btn-default" href="mailto:jczamora@conalep.edu.mx?subject=Solicitud de informes de usuarios registrados para test o post-test&body=Estimado Jesús Chávez:%0D%0A%0D%0ASolicito lista de correos registrador para el plantel cuyo CCT y turno se detalla a continuación:%0D%0ACCT:%0D%0ATurno:">jczamora@conalep.edu.mx</a> o al teléfono <a class="btn btn-default" href="tel:7222710800">7222710800</a> ext 2547
</div>
                <?php $form = ActiveForm::begin(['options'=>['target'=>'_parent']]); ?>
                <div class="row">
                    <div class="col-lg-6">
                    <?= $form->field($model, 'estado')->dropDownList($lentidad,['prompt'=>'Seleccione entidad Federativa', 'id'=>'estado' ]) ?>
                    </div>
                    <div class="col-lg-6">
                    <?=  $form->field($model, 'subsistema')->widget(DepDrop::classname(), [
                    'options'=>['id'=>'subsistema'],
                    'pluginOptions'=>[
                    'depends'=>['estado'],
                    'placeholder'=>'Seleccione subsistema....',
                    'url'=>Url::to(['subsistemas'])
                    ]
                    ]); ?>                       
                    </div>
                </div> 
                <div class="row">
                    <div class="col-lg-6"> 
                    <?= $form->field($model, 'cct')->widget(DepDrop::classname(), [
                    'options'=>['id'=>'cct'],
                    'pluginOptions'=>[
                    'depends'=>['estado', 'subsistema'],
                    'placeholder'=>'Seleccione Plantel...',
                    'url'=>Url::to(['/usuarios/planteles'])
                    ]
                    ]); ?>
                    </div>
                    <div class="col-lg-6">
                     <?= $form->field($model, 'turno')->dropDownList($lturno,['prompt'=>'Seleccione turno ...']) ?>
                     </div>
                </div> 
                <div class="row">
                    <div class="col-lg-6"> 
                    <?= $form->field($model, 'correo')->textInput(['maxlength' => true]) ?>
                    </div>
                    <div class="col-lg-6"> 
                    <?= $form->field($model, 'correo1')->textInput(['maxlength' => true]) ?>
                    </div>
                </div>   
                <div class="row">
                    <div class="col-lg-6">  
                    <?= $form->field($model, 'correo2')->textInput(['maxlength' => true]) ?>
                    </div>
                    <div class="col-lg-6">
                    <?= $form->field($model, 'correo3')->textInput(['maxlength' => true]) ?>
                    </div>
                </div>  
                <div class="row">
                    <div class="col-lg-12">
                    <?= $form->field($model, 'password')->widget(PasswordInput::classname(), [
                    'pluginOptions' => [
                        'showMeter' => FALSE,
                        'toggleMask' => false
                    ]
                    ]); ?>
                    </div> 
                </div> 


    
    <?= $form->errorSummary($model); ?>
   

    <div class="form-group">
        <?= Html::submitButton('Guardar', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

            <div class="row">
                    <div class="col-md-12">
                        <div class="alert alert-warning">
                            <h3>para registrar su plantel vaya al <?= Html::a('Registro de plantel', ['/planteles2019/create', 'id' => $model->id]) ?>, si no se            encuentra en el listado.</h3>
            
                        </div>
                         <?= Html::a('Registro de plantel', ['/planteles2019/create', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
                    </div>

            <div class="form-group"> 
            
    </div>
    
</div>   
<HR class="red">
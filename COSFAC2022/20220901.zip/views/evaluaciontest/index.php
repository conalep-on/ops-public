<?php
/* @var $this yii\web\View */

use yii\bootstrap4\ActiveForm;
?>

 <?= Yii::$app->session->getFlash('msg') ?>

 <div class=" container">


        <h2><?= \yii\bootstrap4\Html::encode($this->title) ?></h2>
    <!--    <div class="alert alert-info">
            <p><b>Comunicado </b><br>
                Aplicación en línea del día lunes 21 de septiembre de 2020.</p>

            <p>Por problemas de la plataforma,<b> los alumnos que presentaban la evaluación en línea el día lunes 21 de septiembre de 2020</b>, se les informa que se ha reprogramo su evaluación para el día lunes 28 de septiembre de 2020 en el mismo horario. Por lo anterior le invitamos a ingresar el día 28 de septiembre en el mismo horario para realizar su evaluación.

                Gracias por su compresión.

            </p>

        </div>  

-->

<img src="<?= yii\helpers\Url::home(true) ?>/examen/EDIEMS_2023.png" alt=""/>

<h2>INSTRUCCIONES PARA RESOLVER LA EVALUACIÓN </h2>
<hr class="red">


<p>El instrumento consta de cinco secciones de preguntas y respuestas, cada una pertenece a las áreas de: Español, Matemáticas, Entorno social, Ciencias naturales y Ética. Antes de contestar, lee las siguientes indicaciones:</p>
<ol>
    <li>Tiene un tiempo de duración de 210 minutos, es decir 3:30 hrs.</li>
    <li>Las preguntas tienen cuatro opciones de respuesta, indicadas con las letras A, B, C y D; sólo una es la respuesta correcta, selecciónala dando clic en el óvalo como se muestra.<br>
    <img src="<?= yii\helpers\Url::home(true) ?>/examen/preguntas.png" alt=""/>
    </li>
    <li>Lee cuidadosamente cada pregunta y elige la respuesta que consideres correcta. Contesta hasta que estés seguro de la respuesta. Si quieres cambiar la respuesta, asegúrate de seleccionar la opción correcta.</li>
    <li>Evita contestar las preguntas al azar, porque las respuestas incorrectas afectarán tu puntuación. Si no sabes cuál es la respuesta correcta de alguna pregunta, es preferible que no marques ninguna y pasa a la siguiente.</li>
    <li>Para visualizar completamente la pregunta tienes una barra(Scroll) que te permitirá bajar el texto.</li>
    <li>En el lado derecho podrá ver el tiempo restante por área y en la parte inferior el nombre del área a presentar.<br>
    <img src="<?= yii\helpers\Url::home(true) ?>/examen/competencia.png" alt=""/>   
   
    
    <li>Una vez iniciada la evaluación el tiempo empieza a correr. </li>
    <li>Al concluir cada área, deberá guardar su información. </li>
    <li>Al concluir la evaluación deberá dar clic en el botón <b>“Finalizar evaluación”</b>.<br>
    <img src="<?= yii\helpers\Url::home(true) ?>/examen/btnfinalizar.png" alt=""/>  
    
    
    <li>Generar y guardar el comprobante que se genera al hacer clic en el botón “Generar comprobante en formato .pdf”
        <br>
        <img src="<?= yii\helpers\Url::home(true) ?>/examen/generarformato.png" alt=""/>  
        
    </li>
    
</ol>
	
<p>&nbsp;</p>

<h2>Ingreso a la evaluación</h2>
<hr class="red">
<div class="alert alert-info" role="alert" style="text-align:justify;">
    <strong>ATENCIÓN:</strong> la contraseña test y post-test son diferentes, escribe correctamente tu contraseña ya que la aplicación es sensible a mayúsculas y minúsculas. También debes estar pendiente del periodo en que estará aperturado el test y post-test, si tu contraseña no es válida, debes comunicarte con tu plantel y verificarla.
</div>
<?php
$form = ActiveForm::begin();
?>
<!--
<?= $form->field($model, 'aplicador')->textInput() ?>
-->
<?= $form->field($model, 'alumno')->textInput(['autofocus' => true,]) ?>

<div class="form-group">
    <div class="col-lg-offset-1 col-lg-11">
        <?= yii\bootstrap4\Html::submitButton('Iniciar evaluación', ['class' => 'btn btn-success', 'name' => 'login-button']) ?>
    </div>
</div>



<?php ActiveForm::end(); ?>

<p>&nbsp;</p>


<?php if (Yii::$app->session->hasFlash('error')): ?>
    <div class="alert alert-danger alert-dismissable">
         <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
         <h4><i class="icon fa fa-check"></i>¡Error!</h4>
         <?= Yii::$app->session->getFlash('error') ?>
    </div>
<?php endif; ?>
<p>&nbsp;</p>
<div class="alert alert-danger">
<p>Estimado estudiante en caso de no contar con tu clave de acceso y fecha para realizar la evaluación en línea, favor de solicitar en tu plantel </p>
 </div>
<p>&nbsp;</p>
<!--
<?=yii\bootstrap4\Html::a('Evaluación Postest', ['/evaluacionposttest'],['class'=>'btn btn-lg btn-primary'])?>

-->
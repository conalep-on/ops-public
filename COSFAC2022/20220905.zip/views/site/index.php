<?php

use yii\bootstrap4\Html;
use kartik\form\ActiveForm;

$lturno = yii\helpers\ArrayHelper::map(app\models\CatalogoTurno::find()->all(), 'id', 'turno');
/* @var $this yii\web\View */

$this->title = 'EVALUACIÓN DIAGNÓSTICA AL INGRESO A LA EDUCACIÓN MEDIA SUPERIOR CICLO ESCOLAR 2022-2023';
?>

<div class="site-index">
    <style>
        .modal-backdrop {
     background-color: rgba(0,0,0,.0001) !important;
}
    </style>
    <div class=" container">
  

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script type="text/javascript">
$(document).ready(function(){
$("#myModal").modal('show');
});
</script>
    
<div id="myModal" class="modal bd-example-modal-lg " >
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">
    
      <div class="modal-body">
        
          <img src="<?= yii\helpers\Url::home(true) ?>infografia.png" alt="" style="width: 100%"/>
      </div>
      <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal"  data-backdrop="false">Cerrar</button>
        
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
        

        
        
        <h3><?= \yii\bootstrap4\Html::encode($this->title) ?></h3>
        
<!--        <div class="alert alert-info">
            <p><b>Comunicado </b><br>
                Aplicación en línea del día lunes 21 de septiembre de 2020.</p>

            <p>Por problemas de la plataforma,<b> los alumnos que presentaban la evaluación en línea el día lunes 21 de septiembre de 2020</b>, se les informa que se ha reprogramo su evaluación para el día lunes 28 de septiembre de 2020 en el mismo horario. Por lo anterior le invitamos a ingresar el día 28 de septiembre en el mismo horario para realizar su evaluación.

                Gracias por su compresión.

            </p>

        </div> -->

        <hr class="red">
        <h3 style="color: #333333" class="text-uppercase"><span class="glyphicon glyphicon-info-sign"></span> PRESENTACIÓN</h3>
        <hr class="red">
        <div class="body-content">

            <p class="text text-justify">
                La <b>Evaluación Diagnóstica al Ingreso a la Educación Media Superior, ciclo escolar 2022-2023</b>, está diseñada para detectar el nivel de dominio de español, matemáticas, entorno social,  ciencias naturales y ética en las y los estudiantes que ingresan al primer año del bachillerato en los subsistemas de Educación Media Superior, para emitir resultados que contribuyan a la toma de decisiones en favor de la mejora del aprendizaje de las y los estudiantes.  
            </p>
            <p class="text text-justify">
               La Evaluación Diagnóstica permite: 
            </p>
            <ul>
                <li>Tener un marco de referencia de la situación de aprendizaje de las y los estudiantes que ingresan al bachillerato. </li>
                <li>Identificar los aprendizajes previos del estudiante en las áreas de acceso al conocimiento y a la experiencia. </li>
                <li>Reforzar los aprendizajes esenciales para la trayectoria educativa en media superior. </li>
                <li>Mejorar continuamente el proceso de enseñanza y de aprendizaje.</li>
                <li>Facilitar a las instituciones educativas información que les sirva para implementar estrategias dirigidas a mejorar el nivel o dominio de español, matemáticas, entorno social,  ciencias naturales y ética.</li>

            </ul>




            <div class="row">
                <div class="col-lg-6">
                            <div class="alert alert-info">
                            <h3 style="color: #333333" class="text-uppercase"><span class="glyphicon glyphicon-edit"></span> &nbsp;Registro (Sólo para el plantel)</h3>
                    

        </div> 
        <hr class="red">

                    <p>Para capturar la información de la Evaluación Diagnóstica deberá registrar el plantel, para ello es necesario la clave del centro de trabajo (CCT) y dos direcciones de correo electrónico.</p>

                    <p> <?= Html::a('Registro', ['/usuarios/create',], ['class' => 'btn btn-info']) ?></p>

                    <p>&nbsp;</p>
             <!-- <div class="alert alert-danger">
<p>Estimado estudiante en caso de no contar con tu clave de acceso y fecha para realizar la evaluación en línea, favor de solicitarla en tu plantel </p>
 </div> -->
                    <p>&nbsp;</p>

                    <h2><span class="glyphicon glyphicon-education"></span>Evaluación en línea</h2>
                    <hr class="red">

                    <div class="alert alert-info" role="alert" style="text-align:justify;">
                        <strong>Alumnos</strong>: utiliza alguna estas opciones para ir al inicio de sesión de test o postest.
                    </div>

                    <?= yii\bootstrap4\Html::a('Evaluación Test en línea', ['/evaluaciontest'], ['class' => 'btn btn-sm  btn-primary']) ?>  


                    <?= yii\bootstrap4\Html::a('Evaluación Postest en línea', ['/evaluacionposttest'], ['class' => 'btn btn-sm btn-primary']) ?>




                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p><span class="icon-user" aria-hidden="true"></span> Soporte Técnico</p>
                    <hr class="red">

                    Para cualquier duda, comentario y aclaración, favor de contactarnos a través de nuestro correo de soporte técnico: <a href="mailto:jczamora@conalep.edu.mx?subject=Solicitud de información de acceso a evaluación diagnóstica">jczamora@conalep.edu.mx</a> 

                </div>
                <div class="col-lg-6">
                    <h3 style="color: #333333" class="text-uppercase"><span class="glyphicon glyphicon-log-in"></span> &nbsp;Acceso al sistema</h3>
                    <hr class="red">

                    <div class="alert alert-info" role="alert" style="text-align:justify;">
                        El siguiente acceso es para uso del plantel.
                    </div>

                    <?php
                    $form = ActiveForm::begin();
                    ?>

                    <?= $form->field($model, 'username', ['addon' => ['prepend' => ['content' => '<span class="glyphicon glyphicon-education"></span>']]])->textInput(['autofocus' => true, 'placeholder' => 'Clave de Centro de Trabajo'])->label(FALSE) ?>
                    <?= $form->field($model, 'turno', ['addon' => ['prepend' => ['content' => '<span class="glyphicon glyphicon-list"></span>']]])->dropDownList($lturno, ['prompt' => 'Seleccione Turno ...'])->label(FALSE) ?>

                    <?= $form->field($model, 'password')->passwordInput() ?>



                    <div class="form-group">
                        <div class="col-lg-offset-1 col-lg-11">
                  <?= Html::submitButton('Iniciar sesión', ['class' => 'btn btn-success', 'name' => 'login-button']) ?> 
                        </div>
                    </div>

                    <?php ActiveForm::end(); ?>


                    <p>&nbsp;</p>
                    <p>&nbsp;</p>
                    <p>&nbsp;</p>

                    <h3 style="color: #333333" class="text-uppercase"><span class="glyphicon glyphicon-log-in"></span> &nbsp;Recuperación de contraseña</h3>
                    <hr class="red">

                    <div class="alert alert-info" role="alert" style="text-align:justify;">
                        El siguiente acceso es para uso del plantel.
                    </div>

                    <?php
                    $form = ActiveForm::begin();
                    ?>

                    <?= $form->field($recupera, 'username', ['addon' => ['prepend' => ['content' => '<span class="glyphicon glyphicon-education"></span>']]])->textInput(['autofocus' => true, 'placeholder' => 'Clave de Centro de Trabajo'])->label(FALSE) ?>
                    <?= $form->field($recupera, 'turno', ['addon' => ['prepend' => ['content' => '<span class="glyphicon glyphicon-list"></span>']]])->dropDownList($lturno, ['prompt' => 'Seleccione Turno ...'])->label(FALSE) ?>

                    <?= $form->errorSummary($recupera); ?>
                    <div class="form-group">
                        <div class="col-lg-offset-1 col-lg-11">
                            <?= Html::submitButton('Recuperar contraseña', ['class' => 'btn btn-info', 'name' => 'login-button']) ?>
                        </div>
                    </div>

                    <?php ActiveForm::end(); ?>


                </div>

            </div>

        </div>




    </div>
</div>

